/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jerap
 */
public class RandomCard {
    void Random(int x) {
        if(x == 0) {
            new Card1().setVisible(true);
        } if(x == 1) {
            new Card2().setVisible(true);
        } if(x == 2) {
            new Card3().setVisible(true);
        } if(x == 3) {
            new Card4().setVisible(true);
        } if(x == 4) {
            new Card5().setVisible(true);
        } if(x == 5) {
            new Card6().setVisible(true);
        } if(x == 6) {
            new Card7().setVisible(true);
        } if(x == 7) {
            new Card8().setVisible(true);
        } if(x == 8) {
            new Card9().setVisible(true);
        } if(x == 9) {
            new Card10().setVisible(true);
        } if(x == 10) {
            new Card11().setVisible(true);
        } if(x == 11) {
            new Card12().setVisible(true);
        } if(x == 12) {
            new Card13().setVisible(true);
        } if(x == 13) {
            new Card14().setVisible(true);
        } if(x == 14) {
            new Card15().setVisible(true);
        } if(x == 15) {
            new Card16().setVisible(true);
        } if(x == 16) {
            new Card17().setVisible(true);
        } if(x == 17) {
            new Card18().setVisible(true);
        } if(x == 18) {
            new Card19().setVisible(true);
        } if(x == 19) {
            new Card20().setVisible(true);
        } if(x == 20) {
            new Card21().setVisible(true);
        } if(x == 21) {
            new Card22().setVisible(true);
        } if(x == 22) {
            new Card23().setVisible(true);
        } if(x == 23) {
            new Card24().setVisible(true);
        } if(x == 24) {
            new Card25().setVisible(true);
        } if(x == 25) {
            new Card26().setVisible(true);
        } if(x == 26) {
            new Card27().setVisible(true);
        } if(x == 27) {
            new Card28().setVisible(true);
        } if(x == 28) {
            new Card29().setVisible(true);
        } if(x == 29) {
            new Card30().setVisible(true);
        } if(x == 30) {
            new Card31().setVisible(true);
        } if(x == 31) {
            new Card32().setVisible(true);
        } if(x == 32) {
            new Card33().setVisible(true);
        } if(x == 33) {
            new Card34().setVisible(true);
        } if(x == 34) {
            new Card35().setVisible(true);
        } if(x == 35) {
            new Card36().setVisible(true);
        } if(x == 36) {
            new Card37().setVisible(true);
        } if(x == 37) {
            new Card38().setVisible(true);
        } if(x == 38) {
            new Card39().setVisible(true);
        } if(x == 39) {
            new Card40().setVisible(true);
        } if(x == 40) {
            new Card41().setVisible(true);
        } if(x == 41) {
            new Card42().setVisible(true);
        } if(x == 42) {
            new Card43().setVisible(true);
        } if(x == 43) {
            new Card44().setVisible(true);
        } if(x == 44) {
            new Card45().setVisible(true);
        } if(x == 45) {
            new Card46().setVisible(true);
        } if(x == 46) {
            new Card47().setVisible(true);
        } if(x == 47) {
            new Card48().setVisible(true);
        } if(x == 48) {
            new Card49().setVisible(true);
        } if(x == 49) {
            new Card50().setVisible(true);
        } if(x == 50) {
            new Card51().setVisible(true);
        } if(x == 51) {
            new Card52().setVisible(true);
        } if(x == 52) {
            new Card53().setVisible(true);
        } if(x == 53) {
            new Card54().setVisible(true);
        } if(x == 54) {
            new Card55().setVisible(true);
        } if(x == 55) {
            new Card56().setVisible(true);
        } if(x == 56) {
            new Card57().setVisible(true);
        } if(x == 57) {
            new Card58().setVisible(true);
        } if(x == 58) {
            new Card59().setVisible(true);
        } if(x == 59) {
            new Card60().setVisible(true);
        } if(x == 60) {
            new Card61().setVisible(true);
        } if(x == 61) {
            new Card62().setVisible(true);
        } if(x == 62) {
            new Card63().setVisible(true);
        } if(x == 63) {
            new Card64().setVisible(true);
        } if(x == 64) {
            new Card65().setVisible(true);
        } if(x == 65) {
            new Card66().setVisible(true);
        } if(x == 66) {
            new Card67().setVisible(true);
        } if(x == 67) {
            new Card68().setVisible(true);
        } if(x == 68) {
            new Card69().setVisible(true);
        } if(x == 69) {
            new Card70().setVisible(true);
        } if(x == 70) {
            new Card71().setVisible(true);
        } if(x == 71) {
            new Card72().setVisible(true);
        } if(x == 72) {
            new Card73().setVisible(true);
        } if(x == 73) {
            new Card74().setVisible(true);
        } if(x == 74) {
            new Card75().setVisible(true);
        } if(x == 75) {
            new Card76().setVisible(true);
        } if(x == 76) {
            new Card77().setVisible(true);
        } if(x == 77) {
            new Card78().setVisible(true);
        } 
}
}

 
